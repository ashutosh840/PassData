package com.example.order10


import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.navigation.fragment.navArgs

/**
 * A simple [Fragment] subclass.
 */
class finalpage : Fragment() {


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val receiveData = arguments?.getString("order_text")!!

        val order_text:TextView?=view?.findViewById(R.id.order_text)
        order_text?.text=receiveData
        return inflater.inflate(R.layout.fragment_finalpage, container, false)
    }


}
