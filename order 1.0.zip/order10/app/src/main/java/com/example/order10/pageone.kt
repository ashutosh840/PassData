package com.example.order10


import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.core.os.bundleOf
import androidx.databinding.DataBindingUtil
import androidx.navigation.findNavController
import com.example.order10.databinding.FragmentPageoneBinding
import kotlinx.android.synthetic.main.fragment_finalpage.view.*
import kotlinx.android.synthetic.main.fragment_pageone.*

/**
 * A simple [Fragment] subclass.
 */
class pageone : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val binding:FragmentPageoneBinding=DataBindingUtil.inflate(layoutInflater,R.layout.fragment_pageone, container, false)

        val buttons= listOf<Button>(binding.orderOne,binding.orderTwo,binding.orderThree,binding.orderFour,binding.orderFive,binding.orderSix,
            binding.orderSeven,binding.orderEight,binding.orderNine,binding.orderTen,
            binding.orderEleven,binding.orderTwelve)

        for (items in buttons)
        {

            items.setOnClickListener {

                changeText(items)
            }

        }




        return binding.root
    }

     fun navigate(text:String){
         val args = bundleOf("order_text" to text)
         view?.findNavController()?.navigate(R.id.action_pageone_to_finalpage,args)
     }



     fun changeText(it:Button){
        when (it){
            order_one->
            {
                navigate("This is order one")
            }
            order_two->
            {
               navigate("This is order two")
            }

            order_three->
            {
                navigate("This is order three")

            }
            order_four->
            {
               navigate("This is order four")
            }
            order_five->
            {
                navigate("This is order five")
            }
            order_six->
            {
                navigate("This is order six")
            }
            order_seven->
            {
               navigate("This is order seven")
            }
            order_eight->
            {
                navigate("This is order eight")

            }
            order_nine->
            {
               navigate("This is order nine")
            }
            order_ten->
            {
               navigate("This is order ten")
            }

            order_eleven->
            {
              navigate("This is order eleven")
            }
            order_twelve->
            {
                navigate("This is order twelve")
            }
        }
    }


}
